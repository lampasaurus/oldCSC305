#ifndef OPENGLERROR_H
#define OPENGLERROR_H

#include <string>
#include <stdint.h>

std::string getErrorString(uint32_t m_ErrorCode);

#endif // OPENGLERROR_H
