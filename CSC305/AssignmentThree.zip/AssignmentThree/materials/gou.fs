#version 150

in vec4 vColor;
out vec4 fColor;

void main()
{
    fColor = vColor;
}